import allure
from allure_commons.types import AttachmentType


def get_screenshot(driver,screenshotName):
    allure.attach(driver.get_screenshot_as_png(), name=screenshotName, attachment_type=AttachmentType.PNG)
