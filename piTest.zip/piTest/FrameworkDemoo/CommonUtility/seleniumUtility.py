import time


def scrollToElement(driver, scrollToElement):
    driver.execute_script("arguments[0].scrollIntoView();", scrollToElement)
    time.sleep(5)
