from selenium.webdriver.common.action_chains import ActionChains
class HomePage():

    def __init__(self,driver):
        self.driver=driver

        self.electronics_category="//span[contains(text(),'Electronics')]"
        self.login_popup_cross_button="//button[@class='_2AkmmA _29YdH8']"
        self.electronics_subcategory_dslr="//a[contains(text(),'DSLR & Mirrorless')]"

    def close_login_popup(self):
        self.driver.find_element_by_xpath(self.login_popup_cross_button).click()

    def open_dslr_sub_category(self):
        action = ActionChains(self.driver)
        electronic_webElement=self.driver.find_element_by_xpath(self.electronics_category)
        action.move_to_element(electronic_webElement).perform()
        self.driver.find_element_by_xpath(self.electronics_subcategory_dslr).click()









