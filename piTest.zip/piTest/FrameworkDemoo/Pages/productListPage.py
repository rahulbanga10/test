import time
from FrameworkDemoo.CommonUtility import seleniumUtility
class ProductListPage():

    def __init__(self,driver):
        self.driver=driver

        self.canon_locator_xpath="//div[@class='_1HmYoV _35HD7C']/descendant::img[contains(@alt,'Canon')]";
        self.next_page_xpath="//a[@class='_3fVaIS']"
        self.page_label_xpath="//span[contains(text(),'Page')]"

    def count_canon_camera(self):
        x=0;
        x+=len(self.driver.find_elements_by_xpath(self.canon_locator_xpath))
        scrollToElement=self.driver.find_element_by_xpath(self.page_label_xpath)
        seleniumUtility.scrollToElement(self.driver,scrollToElement)
        next_button=self.driver.find_element_by_xpath(self.next_page_xpath)
        self.driver.execute_script("arguments[0].click();", next_button)
        x += len(self.driver.find_elements_by_xpath(self.canon_locator_xpath))
        scrollToElement = self.driver.find_element_by_xpath(self.page_label_xpath)
        seleniumUtility.scrollToElement(self.driver,scrollToElement)
        next_button = self.driver.find_element_by_xpath(self.next_page_xpath)
        self.driver.execute_script("arguments[0].click();", next_button)
        x += len(self.driver.find_elements_by_xpath(self.canon_locator_xpath))
        print(x)
        return x
