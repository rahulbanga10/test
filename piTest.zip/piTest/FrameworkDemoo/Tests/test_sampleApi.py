import pytest
import requests
import json
from FrameworkDemoo.Tests.base import Base
from FrameworkDemoo.Config import testConfig


class TestSampleApi(Base):

    @pytest.mark.parametrize("userid, firstname", [(1, "George"), (2, "Janet")])
    def test_list_valid_user(self, userid, firstname):
        test_supply_url = testConfig.api_base_url1 + "/api"
        url = test_supply_url + "/users/" + str(userid)
        resp = requests.get(url)
        j = json.loads(resp.text)
        print(resp.text)
        assert resp.status_code == 200, resp.text
        assert j['data']['id'] == userid, resp.text
        assert j['data']['first_name'] == firstname, resp.text

    def test_list_invaliduser(self):
        test_supply_url = testConfig.api_base_url1 + "/api"
        url = test_supply_url + "/users/50"
        resp = requests.get(url)
        print(resp.text)
        assert resp.status_code == 404, resp.text

    def test_post_headers_body_json(self):
        url = testConfig.api_base_url2 + '/post'

        # Additional headers.
        headers = {'Content-Type': 'application/json'}

        # Body
        payload = {'key1': 1, 'key2': 'value2'}

        # convert dict to json by json.dumps() for body data.
        resp = requests.post(url, data=json.dumps(payload, indent=4))

        # Validate response headers and body contents, e.g. status code.
        assert resp.status_code == 200
        resp_body = resp.json()
        assert resp_body['url'] == url

        # print full request and response
        self.pretty_print_request(resp.request)
        self.pretty_print_response(resp)
