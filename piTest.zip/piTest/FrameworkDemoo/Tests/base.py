from selenium import webdriver
import pytest



class Base():

    @pytest.fixture()
    def test_setup(self):
        self.driver = webdriver.Chrome(executable_path="../FrameworkDemoo/Resources/chromedriver.exe")
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()
        yield
        self.driver.close()
        self.driver.quit()

    def pretty_print_request(self,request):
        print('\n{}\n{}\n\n{}\n\n{}\n'.format(
            '-----------Request----------->',
            request.method + ' ' + request.url,
            '\n'.join('{}: {}'.format(k, v) for k, v in request.headers.items()),
            request.body)
        )

    def pretty_print_response(self,response):
        print('\n{}\n{}\n\n{}\n\n{}\n'.format(
            '<-----------Response-----------',
            'Status code:' + str(response.status_code),
            '\n'.join('{}: {}'.format(k, v) for k, v in response.headers.items()),
            response.text)
        )

