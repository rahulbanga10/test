from selenium import webdriver
import pytest
import allure
from FrameworkDemoo.Tests.base import Base
from FrameworkDemoo.Pages.homePage import HomePage
from FrameworkDemoo.Pages.productListPage import ProductListPage
from FrameworkDemoo.Config import testConfig
from FrameworkDemoo.CommonUtility import allureUtility


class TestSample(Base):

    @allure.severity(allure.severity_level.NORMAL)
    def test_count_cannon_camera(self,test_setup):
        try:
            driver=self.driver
            driver.get(testConfig.ui_app_base_url)
            homePage= HomePage(driver)
            homePage.close_login_popup()
            homePage.open_dslr_sub_categor
            productListPage= ProductListPage(driver)
            canon_count=productListPage.count_canon_camera(3)
            if canon_count==31 :
                assert True
            else:
                assert False
        except:
            allureUtility.get_screenshot(driver,"cannonCount")
            raise

    @allure.severity(allure.severity_level.NORMAL)
    def test_count_cannon_camera2(self, test_setup):
        try:
            driver = self.driver
            driver.get(testConfig.ui_app_base_url)
            homePage = HomePage(driver)
            homePage.close_login_popup()
            homePage.open_dslr_sub_category()
            productListPage = ProductListPage(driver)
            canon_count = productListPage.count_canon_camera()
            if canon_count == 33:
                assert True
            else:
                assert False
        except:
            allureUtility.get_screenshot(driver,"cannon2")
            raise

    @allure.severity(allure.severity_level.NORMAL)
    def test_count_cannon_camera3(self, test_setup):
        try:
            driver = self.driver
            driver.get(testConfig.ui_app_base_url)
            homePage = HomePage(driver)
            homePage.close_login_popup()
            homePage.open_dslr_sub_category()
            productListPage = ProductListPage(driver)
            canon_count = productListPage.count_canon_camera()
            if canon_count == 31:
                assert True
            else:
                assert False
        except:
            allureUtility.get_screenshot(driver,"cannon3")
            raise



