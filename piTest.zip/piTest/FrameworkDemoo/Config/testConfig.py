
ui_app_base_url="http://flipkart.com"
api_base_url1="https://reqres.in"
api_base_url2="https://httpbin.org"